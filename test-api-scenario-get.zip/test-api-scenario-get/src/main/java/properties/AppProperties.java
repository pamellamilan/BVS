package properties;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.LoadPolicy;
import org.aeonbits.owner.Config.LoadType;
import org.aeonbits.owner.Config.Sources;

@LoadPolicy(LoadType.MERGE)
@Sources({"system:properties", "classpath:app.properties"})
public interface AppProperties extends Config {

    @Key("httpTimeout")
    int httpTimeout();

    @Key("baseUri")
    String baseUri();

    @Key("routeUrl")
    String routeUrl();

    @Key("queryParamField")
    String queryParamField();

    @Key("cpf_Valido")
    String cpf_Valido();

    @Key("cpf_Invalido")
    String cpf_Invalido();

    @Key("queryValida")
    String queryValida();

    @Key("queryInvalida")
    String queryInvalida();


}
