package runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"src/test/resources/features"},
        plugin = {"json:target/cluecumber-report/json/cucumber.json", "junit:target/junit.xml"},
        glue = {"steps"},
        tags = "@Postman",
        publish = false)
public class RunTest extends AbstractTestNGCucumberTests {
}
