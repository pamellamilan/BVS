# Testes Automatizados | BVS

# Cenários para validar consulta no componente entity-products-api 

- Para cheque simples 
- Com dados inválidos para cheque simples
- Para cheque completo
- Com dados inválidos para cheque completo

## Pré Requisitos

 - Java JDK 11+
 
