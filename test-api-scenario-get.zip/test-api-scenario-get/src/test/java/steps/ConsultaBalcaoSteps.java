package steps;

import collections.products.GET_CustomerAppointment;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;
import org.hamcrest.core.Is;
import properties.AppConfiguration;
import properties.AppProperties;

import static java.lang.System.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.testng.AssertJUnit.assertTrue;

public class ConsultaBalcaoSteps {

    AppProperties appProperties = AppConfiguration.getProp();
    public String responseBodyAsString;

    // #################### Steps Given ####################

    @Dado("a consulta com dados válidos")
    public void Dado_ConsultaDadosValidos() {
        out.println("consulta cpf válido: " + appProperties.cpf_Valido());
        assertTrue(appProperties.cpf_Valido() != null);
    }

    @Dado("a consulta com dados inválidos")
    public void Dado_ConsultaDadosInvalidos() {
        out.println("consulta cpf inválido: " + appProperties.cpf_Invalido());
        assertTrue(appProperties.cpf_Invalido() != null);
    }

    // #################### Steps When ####################

    @Quando("efetuar a chamada da consulta com estes dados válidos")
    public void Quando_EfetuarChamadaConsulta() {
        responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("cpf_Valido").asString();
        out.println("responseBodyAsString: " + responseBodyAsString);
    }

    @Quando("efetuar a chamada da consulta com estes dados inválidos")
    public void Quando_EfetuarChamadaConsultaDadosInvalidos() {
        responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("cpf_Invalido").asString();
        out.println("responseBodyAsString: " + responseBodyAsString);
    }

    // #################### Steps Then ####################

    @Então("o cpf válido deve constar na resposta")
    public void Entao_CpfValidoDeveConstarNaResposta() {
        assertTrue(responseBodyAsString.contains(appProperties.cpf_Valido()));
        out.println("cpf encontrado: " + appProperties.cpf_Valido());
    }

    @Então("o cpf inválido deve retornar resposta {string}")
    public void Entao_CpfValidoDeveConstarNaResposta(String msg) {
        assertThat(msg, Is.is(responseBodyAsString));
        out.println("Mensagem: " + responseBodyAsString);
    }

}
