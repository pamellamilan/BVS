package steps;

import collections.products.GET_CustomerAppointment;
import collections.products.POST_CustomerAppointment;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;
import org.hamcrest.core.Is;
import properties.AppConfiguration;
import properties.AppProperties;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.testng.AssertJUnit.assertTrue;

public class ConsultaSimplesCpfSteps {

    AppProperties appProperties = AppConfiguration.getProp();
    public String responseBodyAsString;

    // #################### Steps Given ####################

    @Dado("a consulta simples para um cpf válido")
    public void Dado_ChequeSimplesCpf_Valido() {
        System.out.println("Cenário: consulta simples - cpf válido: " + appProperties.consultaSimples_Cpf_Valido());
        assertTrue(appProperties.consultaSimples_Cpf_Valido() != null);
    }

    @Dado("a consulta simples para um cpf inválido")
    public void Dado_ChequeSimplesCpf_Invalido() {
        System.out.println("Cenário: consulta simples - cpf inválido: " + appProperties.consultaSimples_Cpf_Invalido());
        assertTrue(appProperties.consultaSimples_Cpf_Invalido() != null);
    }

    @Dado("a consulta simples para um cpf sem apontamentos")
    public void Dado_ChequeSimplesCpf_SemApontamentos() {
        System.out.println("Cenário: consulta simples - cpf sem apontamentos: " + appProperties.consultaSimples_Cpf_SemApontamentos());
        assertTrue(appProperties.consultaSimples_Cpf_SemApontamentos() != null);
    }

    @Dado("a consulta simples para um cpf não cadastrado")
    public void Dado_ChequeSimplesCpf_NaoCadastrado() {
        System.out.println("Cenário: consulta simples - cpf não cadastrado: " + appProperties.consultaSimples_Cpf_NaoCadastrado());
        assertTrue(appProperties.consultaSimples_Cpf_NaoCadastrado() != null);
    }


    // #################### Steps When ####################

    @Quando("efetuar o tipo de ConsultaSimples_Cpf_Valido na base de dados da BVS")
    public void Quando_EfetuarConsultaSimples_Cpf_Valido() {
        //GET
        //responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("ConsultaSimples_Cpf_Valido").asString();

        //POST
        responseBodyAsString = POST_CustomerAppointment.action().requestScenarioPOST("ConsultaSimples_Cpf_Valido").asString();
        System.out.println("responseBodyAsString: " + responseBodyAsString);
    }

    @Quando("efetuar o tipo de ConsultaSimples_Cpf_Invalido na base de dados da BVS")
    public void Quando_EfetuarConsultaSimples_Cpf_Invalido() {
        //GET
        //responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("ConsultaSimples_Cpf_Invalido").asString();

        //POST
        responseBodyAsString = POST_CustomerAppointment.action().requestScenarioPOST("ConsultaSimples_Cpf_Invalido").asString();
        System.out.println("responseBodyAsString: " + responseBodyAsString);
    }

    @Quando("efetuar o tipo de ConsultaSimples_Cpf_SemApontamentos na base de dados da BVS")
    public void Quando_EfetuarConsultaSimples_Cpf_SemApontamentos() {
        //GET
        //responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("ConsultaSimples_Cpf_SemApontamentos").asString();

        //POST
        responseBodyAsString = POST_CustomerAppointment.action().requestScenarioPOST("ConsultaSimples_Cpf_SemApontamentos").asString();
        System.out.println("responseBodyAsString: " + responseBodyAsString);
    }

    @Quando("efetuar o tipo de ConsultaSimples_Cpf_NaoCadastrado na base de dados da BVS")
    public void Quando_EfetuarConsultaSimples_Cpf_NaoCadastrado() {
        //GET
        //responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("ConsultaSimples_Cpf_NaoCadastrado").asString();

        //POST
        responseBodyAsString = POST_CustomerAppointment.action().requestScenarioPOST("ConsultaSimples_Cpf_NaoCadastrado").asString();
        System.out.println("responseBodyAsString: " + responseBodyAsString);
    }

    // #################### Steps Then ####################

    @Então("o cpf do cliente deve constar no conteúdo da resposta da consulta simples")
    public void Entao_OCpfDoClienteDeveConstarNoConteudoDaRespostaDaConsultaSimples() {
        assertTrue(responseBodyAsString.contains(appProperties.consultaSimples_Cpf_Valido()));
    }

    @Então("a consulta simples deve retornar erro com a mensagem {string}")
    public void Entao_ConsultaSimplesDeveRetornarErroComMensagem(String msg) {
        //assertTrue(responseBodyAsString.contains(msg));
        assertThat(msg, Is.is(responseBodyAsString));
    }

}
