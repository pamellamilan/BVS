package properties;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.LoadPolicy;
import org.aeonbits.owner.Config.LoadType;
import org.aeonbits.owner.Config.Sources;

@LoadPolicy(LoadType.MERGE)
@Sources({"system:properties", "classpath:app.properties"})
public interface AppProperties extends Config {

    @Key("clientCpf")
    String clientCpf();

    @Key("consultaSimples_Cpf_Valido")
    String consultaSimples_Cpf_Valido();

    @Key("consultaSimples_Cpf_Invalido")
    String consultaSimples_Cpf_Invalido();

    @Key("consultaSimples_Cpf_SemApontamentos")
    String consultaSimples_Cpf_SemApontamentos();

    @Key("consultaSimples_Cpf_NaoCadastrado")
    String consultaSimples_Cpf_NaoCadastrado();

    @Key("consultaCompleta_Cpf_Valido")
    String consultaCompleta_Cpf_Valido();

    @Key("consultaCompleta_Cpf_Invalido")
    String consultaCompleta_Cpf_Invalido();

    @Key("consultaCompleta_Cpf_SemApontamentos")
    String consultaCompleta_Cpf_SemApontamentos();

    @Key("consultaCompleta_Cpf_NaoCadastrado")
    String consultaCompleta_Cpf_NaoCadastrado();

    @Key("httpTimeout")
    int httpTimeout();

    @Key("baseUri")
    String baseUri();

    @Key("routeUrl")
    String routeUrl();

    @Key("queryParamField")
    String queryParamField();

    @Key("queryConsultaSimplesCpf_Valido")
    String queryConsultaSimplesCpf_Valido();

    @Key("queryConsultaSimplesCpf_Invalido")
    String queryConsultaSimplesCpf_Invalido();

    @Key("queryConsultaSimplesCpf_SemApontamentos")
    String queryConsultaSimplesCpf_SemApontamentos();

    @Key("queryConsultaSimplesCpf_NaoCadastrado")
    String queryConsultaSimplesCpf_NaoCadastrado();

    @Key("queryConsultaCompletoCpf_Valido")
    String queryConsultaCompletaCpf_Valido();

    @Key("queryConsultaCompletoCpf_Invalido")
    String queryConsultaCompletaCpf_Invalido();

    @Key("queryConsultaCompletoCpf_SemApontamentos")
    String queryConsultaCompletaCpf_SemApontamentos();

    @Key("queryConsultaCompletoCpf_NaoCadastrado")
    String queryConsultaCompletaCpf_NaoCadastrado();


}
