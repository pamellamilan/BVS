package properties;

import org.aeonbits.owner.ConfigCache;

import java.util.Map;

public class AppConfiguration {

    public static AppProperties getProp() {
        return ConfigCache.getOrCreate(AppProperties.class, new Map[0]);
    }
}
