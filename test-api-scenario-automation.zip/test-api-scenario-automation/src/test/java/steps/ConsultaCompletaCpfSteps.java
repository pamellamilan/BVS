package steps;

import collections.products.GET_CustomerAppointment;
import collections.products.POST_CustomerAppointment;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;
import org.hamcrest.core.Is;
import properties.AppConfiguration;
import properties.AppProperties;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.testng.AssertJUnit.assertTrue;

public class ConsultaCompletaCpfSteps {

    AppProperties appProperties = AppConfiguration.getProp();
    public String responseBodyAsString;

    // #################### Steps Given ####################

    @Dado("a consulta completa para um cpf válido")
    public void Dado_ChequeCompletoCpf_Valido() {
        System.out.println("Cenário: consulta completa - cpf válido: " + appProperties.consultaCompleta_Cpf_Valido());
        assertTrue(appProperties.queryConsultaCompletaCpf_Valido() != null);
    }

    @Dado("a consulta completa para um cpf inválido")
    public void Dado_ChequeCompletoCpf_Invalido() {
        System.out.println("Cenário: consulta completa - cpf inválido: " + appProperties.consultaCompleta_Cpf_Invalido());
        assertTrue(appProperties.consultaCompleta_Cpf_Invalido() != null);
    }

    @Dado("a consulta completa para um cpf sem apontamentos")
    public void Dado_ChequeCompletaCpf_SemApontamentos() {
        System.out.println("Cenário: consulta completa - cpf sem apontamentos: " + appProperties.consultaCompleta_Cpf_SemApontamentos());
        assertTrue(appProperties.consultaCompleta_Cpf_SemApontamentos() != null);
    }

    @Dado("a consulta completa para um cpf não cadastrado")
    public void Dado_ChequeCompletaCpf_NaoCadastrado() {
        System.out.println("Cenário: consulta completa - cpf não cadastrado: " + appProperties.consultaCompleta_Cpf_NaoCadastrado());
        assertTrue(appProperties.consultaCompleta_Cpf_NaoCadastrado() != null);
    }

    // #################### Steps When ####################

    @Quando("efetuar o tipo de ConsultaCompleta_Cpf_Valido na base de dados da BVS")
    public void Quando_EfetuarConsultaCompleta_Cpf_Valido() {
        //GET
        //responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("ConsultaCompleta_Cpf_Valido").asString();

        //POST
        responseBodyAsString = POST_CustomerAppointment.action().requestScenarioPOST("ConsultaCompleta_Cpf_Valido").asString();
        System.out.println("responseBodyAsString: " + responseBodyAsString);
    }

    @Quando("efetuar o tipo de ConsultaCompleta_Cpf_Invalido na base de dados da BVS")
    public void Quando_EfetuarConsultaCompleta_Cpf_Invalido() {
        //GET
        //responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("ConsultaCompleta_Cpf_Invalido").asString();

        //POST
        responseBodyAsString = POST_CustomerAppointment.action().requestScenarioPOST("ConsultaCompleta_Cpf_Invalido").asString();
        System.out.println("responseBodyAsString: " + responseBodyAsString);
    }

    @Quando("efetuar o tipo de ConsultaCompleta_Cpf_SemApontamentos na base de dados da BVS")
    public void Quando_EfetuarConsultaCompleta_Cpf_SemApontamentos() {
        //GET
        //responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("ConsultaCompleta_Cpf_SemApontamentos").asString();

        //POST
        responseBodyAsString = POST_CustomerAppointment.action().requestScenarioPOST("ConsultaCompleta_Cpf_SemApontamentos").asString();
        System.out.println("responseBodyAsString: " + responseBodyAsString);
    }

    @Quando("efetuar o tipo de ConsultaCompleta_Cpf_NaoCadastrado na base de dados da BVS")
    public void Quando_EfetuarConsultaCompleta_Cpf_NaoCadastrado() {
        //GET
        //responseBodyAsString = GET_CustomerAppointment.action().requestScenarioGET("ConsultaCompleta_Cpf_NaoCadastrado").asString();

        //POST
        responseBodyAsString = POST_CustomerAppointment.action().requestScenarioPOST("ConsultaCompleta_Cpf_NaoCadastrado").asString();
        System.out.println("responseBodyAsString: " + responseBodyAsString);
    }

    // #################### Steps Then ####################

    @Então("o cpf do cliente deve constar no conteúdo da resposta da consulta completa")
    public void Entao_OCpfDoClienteDeveConstarNoConteudoDaRespostaDaConsultaCompleta() {
        assertTrue(responseBodyAsString.contains(appProperties.consultaCompleta_Cpf_Valido()));
        System.out.println("Finalizando..");
    }

    @Então("a consulta completa deve retornar erro com a mensagem {string}")
    public void Entao_ConsultaCompletaDeveRetornarErroComMensagem(String msg) {
        //assertTrue(responseBodyAsString.contains(msg));
        assertThat(msg, Is.is(responseBodyAsString));
    }

}
