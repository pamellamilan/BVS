package collections.products;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import properties.AppConfiguration;
import properties.AppProperties;

import static io.restassured.RestAssured.config;

public class GET_CustomerAppointment {

    AppProperties appProperties = AppConfiguration.getProp();
    RequestSpecification request;
    private Response response;

    public static GET_CustomerAppointment action() {
        return new GET_CustomerAppointment();
    }

    public RequestSpecification givenRequestScenario(String requestScenario) {
        System.out.println("Montando request..");

        System.out.println("baseUri: " + appProperties.baseUri());
        System.out.println("routeUrl: " + appProperties.routeUrl());
        System.out.println("queryParamField: " + appProperties.queryParamField());

        config = RestAssuredConfig.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .setParam("http.socket.timeout", appProperties.httpTimeout())
                        .setParam("http.connection.timeout", appProperties.httpTimeout()));

        switch (requestScenario) {
            case "ConsultaSimples_Cpf_Valido":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryConsultaSimplesCpf_Valido());
                System.out.println("queryParamValue: " + appProperties.queryConsultaSimplesCpf_Valido());
                break;
            case "ConsultaSimples_Cpf_Invalido":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryConsultaSimplesCpf_Invalido());
                System.out.println("queryParamValue: " + appProperties.queryConsultaSimplesCpf_Invalido());
                break;
            case "queryConsultaSimplesCpf_SemApontamentos":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryConsultaSimplesCpf_SemApontamentos());
                System.out.println("queryParamValue: " + appProperties.queryConsultaSimplesCpf_SemApontamentos());
                break;
            case "queryConsultaSimplesCpf_NaoCadastrado":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryConsultaSimplesCpf_NaoCadastrado());
                System.out.println("queryParamValue: " + appProperties.queryConsultaSimplesCpf_NaoCadastrado());
                break;
            case "ConsultaCompleta_Cpf_Valido":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryConsultaCompletaCpf_Valido());
                System.out.println("queryParamValue: " + appProperties.queryConsultaCompletaCpf_Valido());
                break;
            case "ConsultaCompleta_Cpf_Invalido":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryConsultaCompletaCpf_Invalido());
                System.out.println("queryParamValue: " + appProperties.queryConsultaCompletaCpf_Invalido());
                break;
            case "queryConsultaCompletoCpf_SemApontamentos":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryConsultaCompletaCpf_SemApontamentos());
                System.out.println("queryParamValue: " + appProperties.queryConsultaCompletaCpf_SemApontamentos());
                break;
            case "queryConsultaCompletoCpf_NaoCadastrado":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryConsultaCompletaCpf_NaoCadastrado());
                System.out.println("queryParamValue: " + appProperties.queryConsultaCompletaCpf_NaoCadastrado());
                break;

            default:
                new Exception("Não encontrado um cenário para request!");
                break;
        }
        System.out.println("Chamando request..");
        return request;
    }

    public Response requestScenarioGET(String requestScenarioCpf) {
        response = givenRequestScenario(requestScenarioCpf)
                .when()
                .get(appProperties.baseUri() + appProperties.routeUrl());
        System.out.println("Resposta obtida!");
        return response;
    }

}
