package collections.products;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import properties.AppConfiguration;
import properties.AppProperties;

import static io.restassured.RestAssured.config;

public class GET_CustomerAppointment {

    AppProperties appProperties = AppConfiguration.getProp();
    RequestSpecification request;
    private Response response;

    public static GET_CustomerAppointment action() {
        return new GET_CustomerAppointment();
    }

    public RequestSpecification givenRequestScenario(String requestScenario) {
        System.out.println("Montando request..");

        System.out.println("baseUri: " + appProperties.baseUri());
        System.out.println("routeUrl: " + appProperties.routeUrl());
        System.out.println("queryParamField: " + appProperties.queryParamField());

        config = RestAssuredConfig.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .setParam("http.socket.timeout", appProperties.httpTimeout())
                        .setParam("http.connection.timeout", appProperties.httpTimeout()));

        switch (requestScenario) {
            case "cpf_Valido":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryValida());
                System.out.println("queryParamValue: " + appProperties.queryValida());
                break;
            case "cpf_Invalido":
                request = RestAssured.given().config(config).queryParam(appProperties.queryParamField(), appProperties.queryInvalida());
                System.out.println("queryParamValue: " + appProperties.queryInvalida());
                break;

            default:
                new Exception("Não encontrado um cenário para request!");
                break;
        }
        return request;
    }

    public Response requestScenarioGET(String requestScenarioCpf) {
        System.out.println("Chamando request..");
        response = givenRequestScenario(requestScenarioCpf)
                .when()
                .get(appProperties.baseUri() + appProperties.routeUrl());
        System.out.println("Resposta obtida!");
        return response;
    }

}
